"use strict"

const _lstVoci = document.getElementById("lstVoci");
const _txtNum = document.getElementsByClassName("txtNum");
const _txtStr = document.getElementsByName("txtStr");
const _chk = document.getElementsByTagName("chk");
const _btnControlla = document.getElementById("btnControlla");


function generaNumero(min, max) {
    return Math.floor((max - min) * Math.random()) + min;
}
